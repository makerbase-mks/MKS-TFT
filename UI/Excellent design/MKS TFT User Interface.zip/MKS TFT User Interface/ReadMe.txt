Hello and thank you for downloading my modified version of the MKS TFT User Interface. 



Instructions-

1. copy the contents of the firmware folder to an SD card then insert the card into the readeron the MKS TFT Display. I am using the 3.2" varriant and that is all that will work with this OS. 
2. Power on the board, it will automatically install the firmware. 
3. Once it powers on you are ready to go! 



This interface took alot of design time and effort to put together so I hope that you all apreciate it as a step forward in User Interfaces for 3D Printers. 

All Credit for this UI's Design and assembly goes to me, Isaac Norris, the owner and operator of Dimension 3 Fabrication in Asheville NC. 

I hope that you all get the best from this user interface and share it freely, but I do not want this UI sold as it is Copywriten under the Creative Commons Copywrite. 
The purpose for designing this UI was for the custom Delta 3D Printers that my company, DImension 3, will be manufacturing and the reason that I am sharing this with all of you is that I believe in sharing information,
as the only way to make the world better is to help the spread of ideas. 



Thanks everyone for your support and if you have any questions email me at Dimension3fab@gmail.com or personally at Flightfixit@gmail.com. 
If you want to find me online search FlightFixit for my 3D modeling and Dimension 3 Fabrication for the Delta 3D Printers. 
Hope you all get the best out of my UI. 